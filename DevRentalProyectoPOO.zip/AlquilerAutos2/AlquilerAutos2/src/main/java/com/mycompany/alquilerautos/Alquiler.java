
package com.mycompany.alquilerautos;

public class Alquiler {
    String cedulaCliente;
    String nombreCliente;
    String placaVehiculo;
    String marca;
    int horas;
    double tarifa;
    double total;
    private Cliente cliente;
    private Vehiculo vehiculo;

    public Alquiler(String cedulaCliente, String nombreCliente, String placaVehiculo, String marca, int horas, double tarifa, double total, Cliente cliente, Vehiculo vehiculo) {
        this.cedulaCliente = cedulaCliente;
        this.nombreCliente = nombreCliente;
        this.placaVehiculo = placaVehiculo;
        this.marca = marca;
        this.horas = horas;
        this.tarifa = tarifa;
        this.total = total;
        this.cliente = cliente;
        this.vehiculo = vehiculo;
    }

    public String getCedulaCliente() {
        return cedulaCliente;
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public String getPlacaVehiculo() {
        return placaVehiculo;
    }

    public String getMarca() {
        return marca;
    }

    public int getHoras() {
        return horas;
    }

    public double getTarifa() {
        return tarifa;
    }

    public double getTotal() {
        return total;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public Vehiculo getVehiculo() {
        return vehiculo;
    }

    public void setCedulaCliente(String cedulaCliente) {
        this.cedulaCliente = cedulaCliente;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public void setPlacaVehiculo(String placaVehiculo) {
        this.placaVehiculo = placaVehiculo;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setHoras(int horas) {
        this.horas = horas;
    }

    public void setTarifa(double tarifa) {
        this.tarifa = tarifa;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public void setVehiculo(Vehiculo vehiculo) {
        this.vehiculo = vehiculo;
    }

    public String toCSV(){
        return String.join(",",cliente.getNombre(), String.valueOf(cliente.getCedula()), cliente.getCorreo(), cliente.getDireccion(), 
                vehiculo.getNombre(), vehiculo.getMarca(), vehiculo.getModelo(), String.valueOf(vehiculo.getValorHora()));
    }
    
    
}
