package com.mycompany.alquilerautos;

//import GUI.LoginForm;
import GUI.MenuUsuario;



public class AlquilerAutos {

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> {
            new MenuUsuario().setVisible(true);
        });
    }
}
        
