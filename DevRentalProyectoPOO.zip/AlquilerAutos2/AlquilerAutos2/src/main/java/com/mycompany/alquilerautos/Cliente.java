package com.mycompany.alquilerautos;

import java.util.Scanner;
public class Cliente {
    private String nombre;
    private int cedula;
    private String correo;
    private String direccion;
    private String ciudad;    
    
    
    public Cliente(String nombre,int cedula,String correo,String direccion){
        this.nombre = nombre;
        this.cedula = cedula;
        this.correo = correo;
        this.direccion = direccion;
    }
    
    public String getNombre(){
        return nombre;
    }
    
    public int getCedula(){
        return cedula;
    }
    
    public String getCorreo(){
        return correo;
    }
    
    public String getDireccion(){
        return direccion;
    }
    
    public void setNombre(String nombre){
        this.nombre = nombre;
    }
    
    public void setCedula(int cedula){
        this.cedula = cedula;
    }
    
    public void setCorreo(String correo){
        this.correo = correo;
    }
    
    public void setDireccion(String direccion){
        this.direccion = direccion;
    }
    
  public void pedirDatos() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese el nombre del cliente:");
        this.nombre = scanner.nextLine();
        System.out.println("Ingrese la cedula del cliente:");
        this.cedula = scanner.nextInt();
        scanner.nextLine(); // Consumir el salto de línea
        System.out.println("Ingrese el correo del cliente:");
        this.correo = scanner.nextLine();
        System.out.println("Ingrese la dirección del cliente:");
        this.direccion = scanner.nextLine();
    }

    public void mostrarDatos() {
        System.out.println("Nombre: " + this.nombre);
        System.out.println("Cédula: " + this.cedula);
        System.out.println("Correo: " + this.correo);
        System.out.println("Dirección: " + this.direccion);
    }
    
}
