package MongoConection;

import MongoConection.ConexionMongo;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

public class VehiculoDAO {

    public static void guardarVehiculoCompletoEnMongo(String placa, String marca, String modelo,
        String color, int anio, String tipo, String transmision,
        double precioHora, String estado, String combustible) {
        
        MongoDatabase db = ConexionMongo.getDatabase();
        MongoCollection<Document> coleccion = db.getCollection("vehiculos");

        Document vehiculo = new Document("placa", placa)
                .append("marca", marca)
                .append("modelo", modelo)
                .append("color", color)
                .append("anio", anio)
                .append("tipo", tipo)
                .append("transmision", transmision)
                .append("precioHora", precioHora)
                .append("estado", estado)
                .append("combustible", combustible);

        coleccion.insertOne(vehiculo);
    }
}
