package MongoConection;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

public class ClienteDAO {

    public static void guardarClienteEnMongo(String nombre, String cedula, String genero,
                                             String correo, String direccion, int edad, String telefono) {
        MongoDatabase db = ConexionMongo.getDatabase();
        MongoCollection<Document> coleccion = db.getCollection("clientes");

        Document cliente = new Document("nombre", nombre)
                .append("cedula", cedula)
                .append("genero", genero)
                .append("correo", correo)
                .append("direccion", direccion)
                .append("edad", edad)
                .append("telefono", telefono);

        coleccion.insertOne(cliente);
    }
}
